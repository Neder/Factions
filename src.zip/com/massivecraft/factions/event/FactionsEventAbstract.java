package com.massivecraft.factions.event;

import com.massivecraft.mcore.event.MCoreEvent;

public abstract class FactionsEventAbstract extends MCoreEvent
{

}
