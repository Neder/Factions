package com.massivecraft.factions.event;

public enum FactionsEventChunkChangeType
{
	BUY,
	SELL,
	CONQUER,
	PILLAGE,
	;
}
